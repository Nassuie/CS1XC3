var searchData=
[
  ['print_5fstudent_0',['print_student',['../student_8c.html#a4d964bf73eb1b291728dbf7380a9e6ab',1,'student.c']]]
];
